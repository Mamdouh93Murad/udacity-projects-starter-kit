// to solve ReferenceError: regeneratorRuntime is not defined
// https://knowledge.udacity.com/questions/174638
import 'babel-polyfill'

describe('Client Test', () => {
    // TODO: add your test cases to test client
})

// to solve ReferenceError: regeneratorRuntime is not defined
// https://knowledge.udacity.com/questions/174638
import 'babel-polyfill'

describe('Server Test', () => {
    // TODO: add your test cases to test server
    // HINT: Review
    //  1. https://www.npmjs.com/package/supertest
    //  2. https://dev.to/nedsoft/testing-nodejs-express-api-with-jest-and-supertest-1km6
})
